﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SqlExample;


namespace FinalProjectGUI
{
    public delegate void DataTransfer(string data);
    public partial class Check_Out : Form
    {
        SQLHelper helper = new SQLHelper();

        string custid = null;
        public DataTransfer transferDelegate;

        CheckoutLogin inputForm = null;
        IList<int> Cart;
         
        

        public Check_Out()
        {
            InitializeComponent();
            transferDelegate += new DataTransfer(RecieveInput);
        }

        public void RecieveInput(string data)
        {
            custid = data.ToString();
        }
        ///Database connection/////////////////////////////////////
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        ///Database connection/////////////////////////////////////
        

        private void Check_Out_Load(object sender, EventArgs e)
        {
            
        }

        public void TakeThis(IList<int> listCart)
        {
           
            bool isEmpty = !listCart.Any();
            if (isEmpty)
            {
                MessageBox.Show("Your cart is empty!");
            }
            else
            {
                Cart = listCart;    
                dgvCart.ColumnCount = 3;
                dgvCart.ColumnHeadersVisible = true;
                dgvCart.Columns[0].Name = "Kayak";
                dgvCart.Columns[1].Name = "Color";
                dgvCart.Columns[2].Name = "Price";

                connect();
                float total = 0;
                
                    foreach (int id in listCart)
                    {
                    
                        //Populates cart datagrid with info from the database
                        var name = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        string sprice = price.ToString();
                        float fprice = float.Parse(sprice, System.Globalization.NumberStyles.Currency);
                        total += fprice;
                        lblTax.Text =  String.Format("{0:C}", (total * 0.065));
                        lblTotal.Text = String.Format("{0:C}", ((total * 0.065) + total) + 50);


                    dgvCart.Rows.Add(name.ToString(), color.ToString(), price.ToString());

                    }


                    
                
               
            }
        }



        private void BtnCheckOut_Click(object sender, EventArgs e)
        {
            
            if (custid == null)
            {
                MessageBox.Show("You must be logged in to continue.");
                inputForm = new CheckoutLogin(transferDelegate);
                inputForm.ShowDialog();
            }

            else
            {
                //Takes cart and inputs sales into database
                int count = 0;
                foreach (int id in Cart)
                {
                    try
                    {
                        var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        var cFName = helper.ExecuteScalar("Select First_Name from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        var cLName = helper.ExecuteScalar("Select Last_Name from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        var shipAdd = helper.ExecuteScalar("Select Address from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        var shipCity = helper.ExecuteScalar("Select City from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        var shipState = helper.ExecuteScalar("Select State from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        var shipCountry = helper.ExecuteScalar("Select Country from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        var shipZip = helper.ExecuteScalar("Select Zip_Code from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        var email = helper.ExecuteScalar("Select Email_Address from Customer where Customer_ID = '" + custid + "'", CommandType.Text);
                        DateTime orderTime = DateTime.Now;

                        Random rnd = new Random();
                        int randomNum = rnd.Next(1000000);

                        helper.ExecuteNonQuery("Insert into Orders (Order_ID, Customer_ID, Kayak_ID, Total_Amount, Order_Customer_Name, Order_Ship_Address, Order_City, Order_State, Order_Country, Order_Postal_Code, Order_Shipping, Order_Tax, Order_Email, Order_Tracking, DateTime, Order_Shipped) Values('" + randomNum + "', '"  + custid.ToString() + "', '" + id.ToString() + "', '" + lblTotal.Text + "', '" + cFName + " " + cLName + "', '" + shipAdd + "', '" + shipCity + "', '" + shipState + "', '" + shipCountry + "', '" + shipZip + "', '50', '" + lblTax.Text + "', '" + email + "', '" + rnd.Next(1000000) + "', '" + orderTime.ToShortDateString() + "', 'No')", CommandType.Text);
                        

                        //Removes that kayak from total stock listed in database
                        var inStock = helper.ExecuteScalar("Select Kayak_InStock from Kayak_Inv where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        string sinStock = inStock.ToString();
                        int intInStock = int.Parse(sinStock);

                        helper.ExecuteNonQuery("Update Kayak_Inv Set Kayak_InStock =  '" + (intInStock - 1) + "' Where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        count++;

                        dgvCart.Rows.Clear();
                        dgvCart.Refresh();
                        
                        this.Close();

                        //This is the query for when the table has auto incrementing Order_ID
                        //helper.ExecuteNonQuery("Insert into Orders (Customer_ID, Kayak_ID, Total_Amount, Order_Customer_Name, Order_Ship_Address, Order_City, Order_State, Order_Country, Order_Postal_Code, Order_Tax, Order_Email, DateTime) Values('" + custid.ToString() + "', '" + id.ToString() + "', '" + lblTotal.Text + "', '" + cFName + " " + cLName + "', '" + shipAdd + "', '" + shipCity + "', '" + shipState + "', '" + shipCountry + "', '" + shipZip + "', '" + lblTax.Text + "', '" + email + "', '" + orderTime.ToShortDateString() + "')", CommandType.Text);
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }






                }
                MessageBox.Show("Purchase Successful");
            }

            //Details

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Warning, leaving this page will empty your cart. Are you sure?", "Warning", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                dgvCart.Rows.Clear();
                dgvCart.Refresh();
                this.Close();  
            }
        }
    }
}
