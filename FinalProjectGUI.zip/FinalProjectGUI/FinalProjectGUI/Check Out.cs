﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SqlExample;


namespace FinalProjectGUI
{
    public partial class Check_Out : Form
    {
        SQLHelper helper = new SQLHelper();
        
        public Shop_All MyParent { get; set; }
        

        public Check_Out()
        {
            InitializeComponent();
        }
        ///Database connection--------------------------------------
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        ///Database connection--------------------------------------

        private void Check_Out_Load(object sender, EventArgs e)
        {
            
        }

        public void TakeThis(IList<int> listCart)
        {
           /* if (listCart.ElementAt(0) == 100)
            {
                dgvCart.DataSource = listCart;
                dgvCart.Refresh();
                chboxTest.Checked = true;
            }
*/
            bool isEmpty = !listCart.Any();
            if (isEmpty)
            {
                MessageBox.Show("Your cart is empty!");
            }
            else
            {
                    
                dgvCart.ColumnCount = 3;
                dgvCart.ColumnHeadersVisible = true;
                dgvCart.Columns[0].Name = "Kayak";
                dgvCart.Columns[1].Name = "Color";
                dgvCart.Columns[2].Name = "Price";

                connect();

                    foreach (int id in listCart)
                    {
                        //Populates cart datagrid with info from the database
                        var name = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id.ToString() + "'", CommandType.Text);
                        
                        dgvCart.Rows.Add(name.ToString(), color.ToString(), price.ToString());

                    }


                    
                
               
            }
        }



        private void BtnCheckOut_Click(object sender, EventArgs e)
        {
            dgvCart.Refresh();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Warning, leaving this page will empty your cart. Are you sure?", "Warning", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                dgvCart.Rows.Clear();
                dgvCart.Refresh();
                this.Close();  
            }
        }
    }
}
