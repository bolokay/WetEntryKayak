﻿namespace FinalProjectGUI
{
    partial class EmployeeDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeDashboard));
            this.kayakInvBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pROJECTF2027DataSet1 = new FinalProjectGUI.PROJECTF2027DataSet1();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pROJECTF2027DataSet = new FinalProjectGUI.PROJECTF2027DataSet();
            this.ordersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pROJECTF2027DataSet2 = new FinalProjectGUI.PROJECTF2027DataSet2();
            this.employeeTableAdapter = new FinalProjectGUI.PROJECTF2027DataSetTableAdapters.EmployeeTableAdapter();
            this.kayak_InvTableAdapter = new FinalProjectGUI.PROJECTF2027DataSet1TableAdapters.Kayak_InvTableAdapter();
            this.ordersTableAdapter = new FinalProjectGUI.PROJECTF2027DataSet2TableAdapters.OrdersTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gboxEmployee = new System.Windows.Forms.GroupBox();
            this.btnAddStock = new System.Windows.Forms.Button();
            this.DGInventoryReport = new System.Windows.Forms.DataGridView();
            this.kayakInvIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayakNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayakInStockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BTNBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BTNAddNewKayak = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.BTNAddEmployee = new System.Windows.Forms.Button();
            this.lblEmployeeList = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.DGSalesReport = new System.Windows.Forms.DataGridView();
            this.orderIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayakIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datetimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGEmployeeList = new System.Windows.Forms.DataGridView();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loginUsernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hireDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acessLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnRemove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.kayakInvBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pROJECTF2027DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pROJECTF2027DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pROJECTF2027DataSet2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.gboxEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGInventoryReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGSalesReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGEmployeeList)).BeginInit();
            this.SuspendLayout();
            // 
            // kayakInvBindingSource
            // 
            this.kayakInvBindingSource.DataMember = "Kayak_Inv";
            this.kayakInvBindingSource.DataSource = this.pROJECTF2027DataSet1;
            // 
            // pROJECTF2027DataSet1
            // 
            this.pROJECTF2027DataSet1.DataSetName = "PROJECTF2027DataSet1";
            this.pROJECTF2027DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.pROJECTF2027DataSet;
            // 
            // pROJECTF2027DataSet
            // 
            this.pROJECTF2027DataSet.DataSetName = "PROJECTF2027DataSet";
            this.pROJECTF2027DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ordersBindingSource
            // 
            this.ordersBindingSource.DataMember = "Orders";
            this.ordersBindingSource.DataSource = this.pROJECTF2027DataSet2;
            // 
            // pROJECTF2027DataSet2
            // 
            this.pROJECTF2027DataSet2.DataSetName = "PROJECTF2027DataSet2";
            this.pROJECTF2027DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // kayak_InvTableAdapter
            // 
            this.kayak_InvTableAdapter.ClearBeforeFill = true;
            // 
            // ordersTableAdapter
            // 
            this.ordersTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
            this.groupBox1.Controls.Add(this.gboxEmployee);
            this.groupBox1.Location = new System.Drawing.Point(1, -5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1120, 705);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // gboxEmployee
            // 
            this.gboxEmployee.BackColor = System.Drawing.Color.White;
            this.gboxEmployee.Controls.Add(this.btnRemove);
            this.gboxEmployee.Controls.Add(this.btnAddStock);
            this.gboxEmployee.Controls.Add(this.DGInventoryReport);
            this.gboxEmployee.Controls.Add(this.BTNBack);
            this.gboxEmployee.Controls.Add(this.label1);
            this.gboxEmployee.Controls.Add(this.BTNAddNewKayak);
            this.gboxEmployee.Controls.Add(this.label2);
            this.gboxEmployee.Controls.Add(this.BTNAddEmployee);
            this.gboxEmployee.Controls.Add(this.lblEmployeeList);
            this.gboxEmployee.Controls.Add(this.label4);
            this.gboxEmployee.Controls.Add(this.DGSalesReport);
            this.gboxEmployee.Controls.Add(this.DGEmployeeList);
            this.gboxEmployee.Location = new System.Drawing.Point(84, 19);
            this.gboxEmployee.Name = "gboxEmployee";
            this.gboxEmployee.Size = new System.Drawing.Size(978, 714);
            this.gboxEmployee.TabIndex = 11;
            this.gboxEmployee.TabStop = false;
            // 
            // btnAddStock
            // 
            this.btnAddStock.Location = new System.Drawing.Point(675, 193);
            this.btnAddStock.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddStock.Name = "btnAddStock";
            this.btnAddStock.Size = new System.Drawing.Size(101, 19);
            this.btnAddStock.TabIndex = 12;
            this.btnAddStock.Text = "Add Stock";
            this.btnAddStock.UseVisualStyleBackColor = true;
            this.btnAddStock.Click += new System.EventHandler(this.BtnAddStock_Click);
            // 
            // DGInventoryReport
            // 
            this.DGInventoryReport.AutoGenerateColumns = false;
            this.DGInventoryReport.BackgroundColor = System.Drawing.Color.White;
            this.DGInventoryReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGInventoryReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kayakInvIDDataGridViewTextBoxColumn,
            this.kayakNameDataGridViewTextBoxColumn,
            this.kayakInStockDataGridViewTextBoxColumn});
            this.DGInventoryReport.DataSource = this.kayakInvBindingSource;
            this.DGInventoryReport.Location = new System.Drawing.Point(308, 128);
            this.DGInventoryReport.Margin = new System.Windows.Forms.Padding(2);
            this.DGInventoryReport.Name = "DGInventoryReport";
            this.DGInventoryReport.ReadOnly = true;
            this.DGInventoryReport.RowHeadersWidth = 51;
            this.DGInventoryReport.RowTemplate.Height = 24;
            this.DGInventoryReport.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DGInventoryReport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGInventoryReport.Size = new System.Drawing.Size(363, 122);
            this.DGInventoryReport.TabIndex = 4;
            // 
            // kayakInvIDDataGridViewTextBoxColumn
            // 
            this.kayakInvIDDataGridViewTextBoxColumn.DataPropertyName = "Kayak_Inv_ID";
            this.kayakInvIDDataGridViewTextBoxColumn.HeaderText = "Kayak_Inv_ID";
            this.kayakInvIDDataGridViewTextBoxColumn.Name = "kayakInvIDDataGridViewTextBoxColumn";
            this.kayakInvIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kayakNameDataGridViewTextBoxColumn
            // 
            this.kayakNameDataGridViewTextBoxColumn.DataPropertyName = "Kayak_Name";
            this.kayakNameDataGridViewTextBoxColumn.HeaderText = "Kayak_Name";
            this.kayakNameDataGridViewTextBoxColumn.Name = "kayakNameDataGridViewTextBoxColumn";
            this.kayakNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kayakInStockDataGridViewTextBoxColumn
            // 
            this.kayakInStockDataGridViewTextBoxColumn.DataPropertyName = "Kayak_InStock";
            this.kayakInStockDataGridViewTextBoxColumn.HeaderText = "Kayak_InStock";
            this.kayakInStockDataGridViewTextBoxColumn.Name = "kayakInStockDataGridViewTextBoxColumn";
            this.kayakInStockDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // BTNBack
            // 
            this.BTNBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BTNBack.ForeColor = System.Drawing.Color.Red;
            this.BTNBack.Location = new System.Drawing.Point(877, 18);
            this.BTNBack.Margin = new System.Windows.Forms.Padding(2);
            this.BTNBack.Name = "BTNBack";
            this.BTNBack.Size = new System.Drawing.Size(63, 24);
            this.BTNBack.TabIndex = 10;
            this.BTNBack.Text = "Close";
            this.BTNBack.UseVisualStyleBackColor = true;
            this.BTNBack.Click += new System.EventHandler(this.BTNBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(369, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Dashboard";
            // 
            // BTNAddNewKayak
            // 
            this.BTNAddNewKayak.Location = new System.Drawing.Point(675, 163);
            this.BTNAddNewKayak.Margin = new System.Windows.Forms.Padding(2);
            this.BTNAddNewKayak.Name = "BTNAddNewKayak";
            this.BTNAddNewKayak.Size = new System.Drawing.Size(101, 19);
            this.BTNAddNewKayak.TabIndex = 9;
            this.BTNAddNewKayak.Text = "Add New Kayak";
            this.BTNAddNewKayak.UseVisualStyleBackColor = true;
            this.BTNAddNewKayak.Click += new System.EventHandler(this.BTNAddInventory_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(453, 305);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sales Report";
            // 
            // BTNAddEmployee
            // 
            this.BTNAddEmployee.Location = new System.Drawing.Point(877, 636);
            this.BTNAddEmployee.Margin = new System.Windows.Forms.Padding(2);
            this.BTNAddEmployee.Name = "BTNAddEmployee";
            this.BTNAddEmployee.Size = new System.Drawing.Size(56, 19);
            this.BTNAddEmployee.TabIndex = 8;
            this.BTNAddEmployee.Text = "Add";
            this.BTNAddEmployee.UseVisualStyleBackColor = true;
            this.BTNAddEmployee.Click += new System.EventHandler(this.BTNAddEmployee_Click);
            // 
            // lblEmployeeList
            // 
            this.lblEmployeeList.AutoSize = true;
            this.lblEmployeeList.Location = new System.Drawing.Point(453, 486);
            this.lblEmployeeList.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmployeeList.Name = "lblEmployeeList";
            this.lblEmployeeList.Size = new System.Drawing.Size(72, 13);
            this.lblEmployeeList.TabIndex = 2;
            this.lblEmployeeList.Text = "Employee List";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(446, 101);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Inventory Report";
            // 
            // DGSalesReport
            // 
            this.DGSalesReport.AllowUserToAddRows = false;
            this.DGSalesReport.AllowUserToDeleteRows = false;
            this.DGSalesReport.AutoGenerateColumns = false;
            this.DGSalesReport.BackgroundColor = System.Drawing.Color.White;
            this.DGSalesReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGSalesReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIDDataGridViewTextBoxColumn,
            this.kayakIDDataGridViewTextBoxColumn,
            this.totalAmountDataGridViewTextBoxColumn,
            this.datetimeDataGridViewTextBoxColumn});
            this.DGSalesReport.DataSource = this.ordersBindingSource;
            this.DGSalesReport.Location = new System.Drawing.Point(262, 320);
            this.DGSalesReport.Margin = new System.Windows.Forms.Padding(2);
            this.DGSalesReport.Name = "DGSalesReport";
            this.DGSalesReport.ReadOnly = true;
            this.DGSalesReport.RowHeadersWidth = 51;
            this.DGSalesReport.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DGSalesReport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGSalesReport.Size = new System.Drawing.Size(455, 122);
            this.DGSalesReport.TabIndex = 6;
            // 
            // orderIDDataGridViewTextBoxColumn
            // 
            this.orderIDDataGridViewTextBoxColumn.DataPropertyName = "Order_ID";
            this.orderIDDataGridViewTextBoxColumn.HeaderText = "Order_ID";
            this.orderIDDataGridViewTextBoxColumn.Name = "orderIDDataGridViewTextBoxColumn";
            this.orderIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kayakIDDataGridViewTextBoxColumn
            // 
            this.kayakIDDataGridViewTextBoxColumn.DataPropertyName = "Kayak_ID";
            this.kayakIDDataGridViewTextBoxColumn.HeaderText = "Kayak_ID";
            this.kayakIDDataGridViewTextBoxColumn.Name = "kayakIDDataGridViewTextBoxColumn";
            this.kayakIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // totalAmountDataGridViewTextBoxColumn
            // 
            this.totalAmountDataGridViewTextBoxColumn.DataPropertyName = "Total_Amount";
            this.totalAmountDataGridViewTextBoxColumn.HeaderText = "Total_Amount";
            this.totalAmountDataGridViewTextBoxColumn.Name = "totalAmountDataGridViewTextBoxColumn";
            this.totalAmountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // datetimeDataGridViewTextBoxColumn
            // 
            this.datetimeDataGridViewTextBoxColumn.DataPropertyName = "Datetime";
            this.datetimeDataGridViewTextBoxColumn.HeaderText = "Datetime";
            this.datetimeDataGridViewTextBoxColumn.Name = "datetimeDataGridViewTextBoxColumn";
            this.datetimeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // DGEmployeeList
            // 
            this.DGEmployeeList.AutoGenerateColumns = false;
            this.DGEmployeeList.BackgroundColor = System.Drawing.Color.White;
            this.DGEmployeeList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGEmployeeList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.loginUsernameDataGridViewTextBoxColumn,
            this.hireDateDataGridViewTextBoxColumn,
            this.emailAddressDataGridViewTextBoxColumn,
            this.phoneNumberDataGridViewTextBoxColumn,
            this.acessLevelDataGridViewTextBoxColumn,
            this.employeeTypeDataGridViewTextBoxColumn});
            this.DGEmployeeList.DataSource = this.employeeBindingSource;
            this.DGEmployeeList.Location = new System.Drawing.Point(5, 510);
            this.DGEmployeeList.Margin = new System.Windows.Forms.Padding(2);
            this.DGEmployeeList.MultiSelect = false;
            this.DGEmployeeList.Name = "DGEmployeeList";
            this.DGEmployeeList.RowHeadersWidth = 51;
            this.DGEmployeeList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DGEmployeeList.Size = new System.Drawing.Size(968, 122);
            this.DGEmployeeList.TabIndex = 5;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "Last_Name";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "Last_Name";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "First_Name";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "First_Name";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // loginUsernameDataGridViewTextBoxColumn
            // 
            this.loginUsernameDataGridViewTextBoxColumn.DataPropertyName = "Login_Username";
            this.loginUsernameDataGridViewTextBoxColumn.HeaderText = "Login_Username";
            this.loginUsernameDataGridViewTextBoxColumn.Name = "loginUsernameDataGridViewTextBoxColumn";
            // 
            // hireDateDataGridViewTextBoxColumn
            // 
            this.hireDateDataGridViewTextBoxColumn.DataPropertyName = "Hire_Date";
            this.hireDateDataGridViewTextBoxColumn.HeaderText = "Hire_Date";
            this.hireDateDataGridViewTextBoxColumn.Name = "hireDateDataGridViewTextBoxColumn";
            // 
            // emailAddressDataGridViewTextBoxColumn
            // 
            this.emailAddressDataGridViewTextBoxColumn.DataPropertyName = "Email_Address";
            this.emailAddressDataGridViewTextBoxColumn.HeaderText = "Email_Address";
            this.emailAddressDataGridViewTextBoxColumn.Name = "emailAddressDataGridViewTextBoxColumn";
            // 
            // phoneNumberDataGridViewTextBoxColumn
            // 
            this.phoneNumberDataGridViewTextBoxColumn.DataPropertyName = "Phone_Number";
            this.phoneNumberDataGridViewTextBoxColumn.HeaderText = "Phone_Number";
            this.phoneNumberDataGridViewTextBoxColumn.Name = "phoneNumberDataGridViewTextBoxColumn";
            // 
            // acessLevelDataGridViewTextBoxColumn
            // 
            this.acessLevelDataGridViewTextBoxColumn.DataPropertyName = "Acess_Level";
            this.acessLevelDataGridViewTextBoxColumn.HeaderText = "Acess_Level";
            this.acessLevelDataGridViewTextBoxColumn.Name = "acessLevelDataGridViewTextBoxColumn";
            // 
            // employeeTypeDataGridViewTextBoxColumn
            // 
            this.employeeTypeDataGridViewTextBoxColumn.DataPropertyName = "Employee_Type";
            this.employeeTypeDataGridViewTextBoxColumn.HeaderText = "Employee_Type";
            this.employeeTypeDataGridViewTextBoxColumn.Name = "employeeTypeDataGridViewTextBoxColumn";
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(795, 636);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(2);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(56, 19);
            this.btnRemove.TabIndex = 13;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.BtnRemove_Click);
            // 
            // EmployeeDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 566);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "EmployeeDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Dashboard";
            this.Load += new System.EventHandler(this.EmployeeDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kayakInvBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pROJECTF2027DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pROJECTF2027DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pROJECTF2027DataSet2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.gboxEmployee.ResumeLayout(false);
            this.gboxEmployee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGInventoryReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGSalesReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGEmployeeList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblEmployeeList;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView DGInventoryReport;
        private System.Windows.Forms.DataGridView DGEmployeeList;
        private System.Windows.Forms.DataGridView DGSalesReport;
        private System.Windows.Forms.Button BTNAddEmployee;
        private System.Windows.Forms.Button BTNAddNewKayak;
        private System.Windows.Forms.Button BTNBack;
        private System.Windows.Forms.GroupBox gboxEmployee;
        private System.Windows.Forms.GroupBox groupBox1;
        private PROJECTF2027DataSet pROJECTF2027DataSet;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private PROJECTF2027DataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loginUsernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hireDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acessLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeTypeDataGridViewTextBoxColumn;
        private PROJECTF2027DataSet1 pROJECTF2027DataSet1;
        private System.Windows.Forms.BindingSource kayakInvBindingSource;
        private PROJECTF2027DataSet1TableAdapters.Kayak_InvTableAdapter kayak_InvTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayakInvIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayakNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayakInStockDataGridViewTextBoxColumn;
        private PROJECTF2027DataSet2 pROJECTF2027DataSet2;
        private System.Windows.Forms.BindingSource ordersBindingSource;
        private PROJECTF2027DataSet2TableAdapters.OrdersTableAdapter ordersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayakIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datetimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnAddStock;
        private System.Windows.Forms.Button btnRemove;
    }
}