﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SqlExample;

namespace FinalProjectGUI
{
    public partial class New_Kayaks : Form
    {
        SQLHelper helper = new SQLHelper();
        IList<int> listCart = new List<int>();

        //Database connection/////////////////////////////////////
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //Database connection/////////////////////////////////////

        private bool checkStock(int kayakID)
        {
            connect();
            var stockNum = helper.ExecuteScalar("Select Kayak_InStock from Kayak_Inv where Kayak_ID = '" + kayakID + "'", CommandType.Text);
            string stock = stockNum.ToString();
            int stockNumber = int.Parse(stock);

            if (stockNumber >= 1)
                return true;
            else
                return false;

        }

        public New_Kayaks()
        {
            InitializeComponent();
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            int id = 100;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {

                    listCart.Add(100);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }
    }
}
