﻿namespace FinalProjectGUI
{
    partial class CustomerDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerDashboard));
            this.label1 = new System.Windows.Forms.Label();
            this.DGCustomerInfo = new System.Windows.Forms.DataGridView();
            this.BTNUpdateInfo = new System.Windows.Forms.Button();
            this.BTNOrderTracking = new System.Windows.Forms.Button();
            this.BTNBack = new System.Windows.Forms.Button();
            this.gboxEmployee = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.DGCustomerInfo)).BeginInit();
            this.gboxEmployee.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(369, 66);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Dashboard";
            // 
            // DGCustomerInfo
            // 
            this.DGCustomerInfo.BackgroundColor = System.Drawing.Color.White;
            this.DGCustomerInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGCustomerInfo.GridColor = System.Drawing.Color.White;
            this.DGCustomerInfo.Location = new System.Drawing.Point(29, 137);
            this.DGCustomerInfo.Margin = new System.Windows.Forms.Padding(2);
            this.DGCustomerInfo.MultiSelect = false;
            this.DGCustomerInfo.Name = "DGCustomerInfo";
            this.DGCustomerInfo.RowHeadersWidth = 51;
            this.DGCustomerInfo.RowTemplate.Height = 24;
            this.DGCustomerInfo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.DGCustomerInfo.Size = new System.Drawing.Size(939, 54);
            this.DGCustomerInfo.TabIndex = 2;
            // 
            // BTNUpdateInfo
            // 
            this.BTNUpdateInfo.Location = new System.Drawing.Point(328, 238);
            this.BTNUpdateInfo.Margin = new System.Windows.Forms.Padding(2);
            this.BTNUpdateInfo.Name = "BTNUpdateInfo";
            this.BTNUpdateInfo.Size = new System.Drawing.Size(89, 25);
            this.BTNUpdateInfo.TabIndex = 3;
            this.BTNUpdateInfo.Text = "Update Info";
            this.BTNUpdateInfo.UseVisualStyleBackColor = true;
            this.BTNUpdateInfo.Click += new System.EventHandler(this.BTNUpdateInfo_Click);
            // 
            // BTNOrderTracking
            // 
            this.BTNOrderTracking.Location = new System.Drawing.Point(588, 238);
            this.BTNOrderTracking.Margin = new System.Windows.Forms.Padding(2);
            this.BTNOrderTracking.Name = "BTNOrderTracking";
            this.BTNOrderTracking.Size = new System.Drawing.Size(89, 25);
            this.BTNOrderTracking.TabIndex = 5;
            this.BTNOrderTracking.Text = "Order Tracking";
            this.BTNOrderTracking.UseVisualStyleBackColor = true;
            this.BTNOrderTracking.Click += new System.EventHandler(this.BTNOrderTracking_Click);
            // 
            // BTNBack
            // 
            this.BTNBack.Location = new System.Drawing.Point(458, 318);
            this.BTNBack.Margin = new System.Windows.Forms.Padding(2);
            this.BTNBack.Name = "BTNBack";
            this.BTNBack.Size = new System.Drawing.Size(89, 25);
            this.BTNBack.TabIndex = 6;
            this.BTNBack.Text = "Back";
            this.BTNBack.UseVisualStyleBackColor = true;
            this.BTNBack.Click += new System.EventHandler(this.BTNBack_Click);
            // 
            // gboxEmployee
            // 
            this.gboxEmployee.Controls.Add(this.DGCustomerInfo);
            this.gboxEmployee.Controls.Add(this.BTNBack);
            this.gboxEmployee.Controls.Add(this.label1);
            this.gboxEmployee.Controls.Add(this.BTNOrderTracking);
            this.gboxEmployee.Controls.Add(this.BTNUpdateInfo);
            this.gboxEmployee.Location = new System.Drawing.Point(76, 0);
            this.gboxEmployee.Name = "gboxEmployee";
            this.gboxEmployee.Size = new System.Drawing.Size(997, 578);
            this.gboxEmployee.TabIndex = 12;
            this.gboxEmployee.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
            this.groupBox1.Controls.Add(this.gboxEmployee);
            this.groupBox1.Location = new System.Drawing.Point(0, -5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1147, 572);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // CustomerDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 566);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CustomerDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Dashboard";
            this.Load += new System.EventHandler(this.CustomerDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGCustomerInfo)).EndInit();
            this.gboxEmployee.ResumeLayout(false);
            this.gboxEmployee.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView DGCustomerInfo;
        private System.Windows.Forms.Button BTNUpdateInfo;
        private System.Windows.Forms.Button BTNOrderTracking;
        private System.Windows.Forms.Button BTNBack;
        private System.Windows.Forms.GroupBox gboxEmployee;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}