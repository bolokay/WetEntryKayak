﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SqlExample;

namespace FinalProjectGUI
{
    public partial class Create_Account : Form
    {
        SQLHelper helper = new SQLHelper();

        public Create_Account()
        {
            InitializeComponent();
        }
        ///Database connection/////////////////////////////////////
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        ///Database connection/////////////////////////////////////
        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            //Checks connection the the sql database
            connect();
            if ((txt1.Text.Length > 0) && (txt2.Text.Length > 0) && (txt3.Text.Length > 0) && (txt4.Text.Length > 0) && (txt5.Text.Length > 0) && (txt6.Text.Length > 0) && (txt7.Text.Length > 0) && (txt8.Text.Length > 0) && (txt9.Text.Length > 0) && (txt10.Text.Length > 0) && (txt11.Text.Length > 0))
            {
                try
                {
                    helper.ExecuteNonQuery("INSERT INTO Customer(Email_Address, First_Name, Last_Name, Country, State, City, Zip_Code, Address, Phone_Number) VALUES ('" + txt3.Text + "','" + txt4.Text + "','" + txt5.Text + "','" + txt6.Text + "','" + txt7.Text + "','" + txt8.Text + "','" + txt9.Text + "','" + txt10.Text + "','" + txt11.Text + "')", CommandType.Text);

                    var custid = helper.ExecuteScalar("Select Customer_ID from Customer Where Email_Address = '" + txt3.Text + "'", CommandType.Text);
                    helper.ExecuteNonQuery("Insert into UserID_Password (User_Name, Password, Customer_ID) Values ('" + txt1.Text + "','" + txt2.Text + "','" + custid.ToString() + "')", CommandType.Text);

                    MessageBox.Show("Success");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBox.Show("All fields must be completed!");
           
        }
    }
}
