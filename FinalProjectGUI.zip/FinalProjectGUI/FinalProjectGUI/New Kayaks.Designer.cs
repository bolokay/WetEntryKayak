﻿namespace FinalProjectGUI
{
    partial class New_Kayaks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(New_Kayaks));
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblKayak2 = new System.Windows.Forms.Label();
            this.lblKayak1 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gboxOcean = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Woodcut", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblHeader.Location = new System.Drawing.Point(167, 13);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(800, 50);
            this.lblHeader.TabIndex = 99;
            this.lblHeader.Text = "Wet Entry Kayaks";
            // 
            // lblKayak2
            // 
            this.lblKayak2.AutoSize = true;
            this.lblKayak2.Font = new System.Drawing.Font("Showcard Gothic", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKayak2.Location = new System.Drawing.Point(648, 198);
            this.lblKayak2.Name = "lblKayak2";
            this.lblKayak2.Size = new System.Drawing.Size(387, 43);
            this.lblKayak2.TabIndex = 98;
            this.lblKayak2.Text = "White Water Kayak";
            // 
            // lblKayak1
            // 
            this.lblKayak1.AutoSize = true;
            this.lblKayak1.Font = new System.Drawing.Font("Showcard Gothic", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKayak1.Location = new System.Drawing.Point(176, 198);
            this.lblKayak1.Name = "lblKayak1";
            this.lblKayak1.Size = new System.Drawing.Size(249, 43);
            this.lblKayak1.TabIndex = 97;
            this.lblKayak1.Text = "Ocean Kayak";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::FinalProjectGUI.Properties.Resources.Lime_Kayak;
            this.pictureBox8.Location = new System.Drawing.Point(651, 270);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(357, 195);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 94;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::FinalProjectGUI.Properties.Resources.Ocean_Kayak;
            this.pictureBox3.Location = new System.Drawing.Point(17, 212);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(515, 296);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 93;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(339, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(456, 24);
            this.label1.TabIndex = 100;
            this.label1.Text = "Make waves with our newest models!";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Location = new System.Drawing.Point(59, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1009, 568);
            this.groupBox1.TabIndex = 101;
            this.groupBox1.TabStop = false;
            // 
            // gboxOcean
            // 
            this.gboxOcean.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gboxOcean.BackgroundImage")));
            this.gboxOcean.Location = new System.Drawing.Point(0, 0);
            this.gboxOcean.Name = "gboxOcean";
            this.gboxOcean.Size = new System.Drawing.Size(1125, 1647);
            this.gboxOcean.TabIndex = 102;
            this.gboxOcean.TabStop = false;
            // 
            // New_Kayaks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 566);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.lblKayak2);
            this.Controls.Add(this.lblKayak1);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gboxOcean);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "New_Kayaks";
            this.Text = "New Kayaks";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblKayak2;
        private System.Windows.Forms.Label lblKayak1;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox gboxOcean;
    }
}