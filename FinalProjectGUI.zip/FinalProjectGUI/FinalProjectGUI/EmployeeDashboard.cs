﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;
using SqlExample;

namespace FinalProjectGUI
{
    public partial class EmployeeDashboard : Form
    {
        SQLHelper helper = new SQLHelper();
        bool accessLevel;

        ///Database connection/////////////////////////////////////
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        ///Database connection/////////////////////////////////////

        public EmployeeDashboard(bool isManager)
        {
            InitializeComponent();
            accessLevel = isManager;
            if (!isManager)
            {
                BTNAddEmployee.Enabled = false;
                BTNAddEmployee.Visible = false;
                btnRemove.Enabled = false;
                btnRemove.Visible = false;
                DGEmployeeList.Visible = false;
                DGEmployeeList.Enabled = false;
                lblEmployeeList.Visible = false;
            }
        }

        private void EmployeeDashboard_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pROJECTF2027DataSet2.Orders' table. You can move, or remove it, as needed.
            this.ordersTableAdapter.Fill(this.pROJECTF2027DataSet2.Orders);
            // TODO: This line of code loads data into the 'pROJECTF2027DataSet1.Kayak_Inv' table. You can move, or remove it, as needed.
            this.kayak_InvTableAdapter.Fill(this.pROJECTF2027DataSet1.Kayak_Inv);
            // TODO: This line of code loads data into the 'pROJECTF2027DataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.pROJECTF2027DataSet.Employee);

            

            SqlConnection con = new SqlConnection("Data source=essql1.walton.uark.edu;" +
                        "Initial Catalog=PROJECTF2027;" +
                        "USER ID=PROJECTF2027;Password=SH93ack$");

            SqlCommand cmd = new SqlCommand("Select * from Orders", con);

            DbDataReader myreader;

            try

            {

                con.Open();

                myreader = cmd.ExecuteReader();


            }

    catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        private void BTNBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        //Opens New form to insert a new Kayak into the database
        private void BTNAddInventory_Click(object sender, EventArgs e)
        {
            AddInventory addI = new AddInventory();
            addI.ShowDialog();
        }

        private void BtnAddStock_Click(object sender, EventArgs e)
        {
            //Adds 10 of selected kayak to stock
            DialogResult result = MessageBox.Show("Do you want to add 10 of the selected kayaks to inventory?", "Add inventory", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                connect();
                    string id = DGInventoryReport.CurrentRow.Cells[0].Value.ToString();

                    var stock = helper.ExecuteScalar("Select Kayak_InStock From Kayak_Inv where Kayak_Inv_ID = '" + id +"'", CommandType.Text);
                string stockString = stock.ToString();
                int stockInt = int.Parse(stockString);
                stockInt += 10;

                helper.ExecuteNonQuery("Update Kayak_Inv Set Kayak_InStock = '" + stockInt.ToString() + "' Where Kayak_Inv_ID = '" + id + "'", CommandType.Text);
                MessageBox.Show("Success");
                DGInventoryReport.Refresh();
            }
        }

        private void BTNAddEmployee_Click(object sender, EventArgs e)
        {
            connect();
            try
            {
                //Database table doesn't auto increment
                var newID = helper.ExecuteScalar("  SELECT MAX(Employee_ID) FROM Employee", CommandType.Text);

                string stringNewID = newID.ToString();
                int intNewID = int.Parse(stringNewID);
                intNewID += 1;


              
                string lname = DGEmployeeList.CurrentRow.Cells[1].Value.ToString();
                string fname = DGEmployeeList.CurrentRow.Cells[2].Value.ToString();
                
                string login_User = DGEmployeeList.CurrentRow.Cells[3].Value.ToString();
                string hireDate = DGEmployeeList.CurrentRow.Cells[4].Value.ToString();
                string email = DGEmployeeList.CurrentRow.Cells[5].Value.ToString();
                string phone = DGEmployeeList.CurrentRow.Cells[6].Value.ToString();
                string accessLevel = DGEmployeeList.CurrentRow.Cells[7].Value.ToString();
                string type = DGEmployeeList.CurrentRow.Cells[8].Value.ToString();
                

                helper.ExecuteNonQuery("Insert into Employee Values ( '" + intNewID + "', '" + lname + "', '" + fname + "', '" + login_User + "', '" + hireDate + "', '" + email + "', '" + phone + "', '" + accessLevel + "', '" + type + "')", CommandType.Text);
                MessageBox.Show("Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            //Removes employee from database
            DialogResult result = MessageBox.Show("Warning, do you wish to remove the selected employee?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                connect();
                helper.ExecuteNonQuery("Delete from Employee where Employee_ID = '" + DGEmployeeList.CurrentRow.Cells[0].Value.ToString() + "'", CommandType.Text);
                DGEmployeeList.Refresh();
                MessageBox.Show("Employee successfully removed");
            }
        }

    }
}
