﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProjectGUI
{
    public partial class EmployeeDashboard : Form
    {
        public EmployeeDashboard()
        {
            InitializeComponent();
        }

        private void EmployeeDashboard_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pROJECTF2027DataSet2.Orders' table. You can move, or remove it, as needed.
            this.ordersTableAdapter.Fill(this.pROJECTF2027DataSet2.Orders);
            // TODO: This line of code loads data into the 'pROJECTF2027DataSet1.Kayak_Inv' table. You can move, or remove it, as needed.
            this.kayak_InvTableAdapter.Fill(this.pROJECTF2027DataSet1.Kayak_Inv);
            // TODO: This line of code loads data into the 'pROJECTF2027DataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.pROJECTF2027DataSet.Employee);

        }

        private void BTNBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
