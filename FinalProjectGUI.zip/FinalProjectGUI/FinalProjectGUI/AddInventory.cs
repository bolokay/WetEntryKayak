﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SqlExample;

namespace FinalProjectGUI
{
    public partial class AddInventory : Form
    {
        SQLHelper helper = new SQLHelper();

        public AddInventory()
        {
            InitializeComponent();
            connect();
        }

        ///Database connection/////////////////////////////////////
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        ///Database connection/////////////////////////////////////

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //Database table doesn't auto increment
                var newID = helper.ExecuteScalar("  SELECT MAX(CAST(SUBSTRING(Kayak_ID, 1, 10) AS INT)) FROM Kayaks", CommandType.Text);

                string stringNewID = newID.ToString();
                int intNewID = int.Parse(stringNewID);
                intNewID += 100;
                int capacity = int.Parse(txtKayakCapacity.Text);
                helper.ExecuteNonQuery("Insert into Kayaks (Kayak_ID, Kayak_Type, Kayak_Color, Kayak_Name, Kayak_Weight, Kayak_Capacity, Kayak_Price, Kayak_Length, Dicription) Values ('" + intNewID.ToString() + "', '" + txtKayakType.Text + "', '" + txtKayakColor.Text + "', '" + txtKayakName.Text + "', '" + txtKayakWeight.Text + "', '" + txtKayakCapacity.Text + "', '" + txtKayakPrice.Text + "', '" + txtKayakLength.Text + "', '" + txtDescription.Text + "')", CommandType.Text);
                helper.ExecuteNonQuery("Insert into Kayak_Inv (Kayak_Inv_ID, Kayak_ID, Kayak_Name, Kayak_Color, Kayak_Weight, Kayak_Cappacity, Kayak_Lenght, Kayak_InStock) Values ('" + intNewID.ToString() + "', '" + intNewID.ToString() + "', '" + txtKayakName.Text + "', '" + txtKayakColor.Text + "', '" + txtKayakWeight.Text + "', '" + capacity + "', '" + txtKayakLength.Text + "', '" + txtAmount.Text + "')", CommandType.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            MessageBox.Show("Successfully added");
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
