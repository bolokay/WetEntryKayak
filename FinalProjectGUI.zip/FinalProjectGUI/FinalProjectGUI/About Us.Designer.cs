﻿namespace FinalProjectGUI
{
    partial class About_Us
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(About_Us));
            this.label1 = new System.Windows.Forms.Label();
            this.gboxBackground = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gboxAboutUs = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.gboxAboutUs.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(33, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 31);
            this.label1.TabIndex = 5;
            this.label1.Text = "About Us";
            // 
            // gboxBackground
            // 
            this.gboxBackground.ForeColor = System.Drawing.Color.White;
            this.gboxBackground.Location = new System.Drawing.Point(-2, 2);
            this.gboxBackground.Name = "gboxBackground";
            this.gboxBackground.Size = new System.Drawing.Size(1148, 566);
            this.gboxBackground.TabIndex = 7;
            this.gboxBackground.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox2.BackgroundImage")));
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox2.Controls.Add(this.gboxAboutUs);
            this.groupBox2.Location = new System.Drawing.Point(-2, -8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1158, 576);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            // 
            // gboxAboutUs
            // 
            this.gboxAboutUs.Controls.Add(this.label2);
            this.gboxAboutUs.Controls.Add(this.label1);
            this.gboxAboutUs.Location = new System.Drawing.Point(109, 120);
            this.gboxAboutUs.Name = "gboxAboutUs";
            this.gboxAboutUs.Size = new System.Drawing.Size(546, 206);
            this.gboxAboutUs.TabIndex = 7;
            this.gboxAboutUs.TabStop = false;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(37, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(484, 162);
            this.label2.TabIndex = 8;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // About_Us
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 566);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gboxBackground);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "About_Us";
            this.Text = "About Us";
            this.Load += new System.EventHandler(this.About_Us_Load);
            this.groupBox2.ResumeLayout(false);
            this.gboxAboutUs.ResumeLayout(false);
            this.gboxAboutUs.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gboxBackground;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox gboxAboutUs;
        private System.Windows.Forms.Label label2;
    }
}