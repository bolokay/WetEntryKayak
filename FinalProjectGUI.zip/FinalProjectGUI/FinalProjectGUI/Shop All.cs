﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using SqlExample;

namespace FinalProjectGUI
{
    
    public partial class Shop_All : Form 
    {
        public bool kayak1 = false;
        public bool kayak2 = false;
        public bool kayak3 = false;
        public bool kayak4 = false;
        public bool kayak5 = false;
        public bool kayak6 = false;
        public bool kayak7 = false;
        public bool kayak8 = false;

        Check_Out co = new Check_Out();
        

        IList<int> listCart = new List<int>();
        SQLHelper helper = new SQLHelper();

        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private bool checkStock(int kayakID)
        {
            connect();
            var stockNum = helper.ExecuteScalar("Select Kayak_InStock from Kayak_Inv where Kayak_ID = '" + kayakID + "'", CommandType.Text);
            string stock = stockNum.ToString();
            int stockNumber = int.Parse(stock);

            if (stockNumber >= 1)
                return true;
            else
                return false;

        }

        public void clear()
        {
            listCart.Clear();
        }

        public Shop_All()
        {
            InitializeComponent();
        }

        

        public void openCheckOut()
        {

            bool isEmpty = !listCart.Any();
            if (isEmpty)
            {
                MessageBox.Show("Your cart is empty!");
            }
            else
            {
                co.TakeThis(listCart);
                co.StartPosition = FormStartPosition.CenterScreen;
                co.ShowDialog();
                listCart.Clear();
            }
            
        }

        private void BtnAddToCart_Click(object sender, EventArgs e)
        {
            openCheckOut();
        }

       

        private void Shop_All_Load(object sender, EventArgs e)
        {
            this.ActiveControl = lblHeader;
            

        }

       

        private void PictureBox3_Click(object sender, EventArgs e)
        {

            if (checkStock(100))
            {
                DialogResult result = MessageBox.Show("     Ocean Kayak \n     Color: Yellow \n     Weight: 36lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {

                    listCart.Add(100);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox8_Click(object sender, EventArgs e)
        {
            if (checkStock(200))
            {
                DialogResult result = MessageBox.Show("     White Water Kayak \n     Color: Green \n     Weight: 41lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(200);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

       

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            if (checkStock(300))
            {
                DialogResult result = MessageBox.Show("     White Water Kayak \n     Color: Green \n     Weight: 41lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(300);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }


        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (checkStock(400))
            {
                DialogResult result = MessageBox.Show("     White Water Kayak \n     Color: Green \n     Weight: 41lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(400);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox7_Click(object sender, EventArgs e)
        {
            if (checkStock(500))
            {
                DialogResult result = MessageBox.Show("     White Water Kayak \n     Color: Green \n     Weight: 41lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(500);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox6_Click(object sender, EventArgs e)
        {
            if (checkStock(600))
            {
                DialogResult result = MessageBox.Show("     White Water Kayak \n     Color: Green \n     Weight: 41lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(600);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            if (checkStock(700))
            {
                DialogResult result = MessageBox.Show("     White Water Kayak \n     Color: Green \n     Weight: 41lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(700);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {
            if (checkStock(800))
            {
                DialogResult result = MessageBox.Show("     White Water Kayak \n     Color: Green \n     Weight: 41lbs \n     Capacity: 1 \n     Length: 8ft     \n     Add to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(800);

                }
            }

            else
                MessageBox.Show("Currently Out of Stock!");
        }
    }
}
