﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using SqlExample;

namespace FinalProjectGUI
{
    
    public partial class Shop_All : Form 
    {
        Check_Out co = new Check_Out();
        

        IList<int> listCart = new List<int>();
        SQLHelper helper = new SQLHelper();

        //Database connection/////////////////////////////////////
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //Database connection/////////////////////////////////////


        //Checks to see if the Kayak is in stock before displaying details and asking if user wants to add to cart
        private bool checkStock(int kayakID)
        {
            connect();
            var stockNum = helper.ExecuteScalar("Select Kayak_InStock from Kayak_Inv where Kayak_ID = '" + kayakID + "'", CommandType.Text);
            string stock = stockNum.ToString();
            int stockNumber = int.Parse(stock);

            if (stockNumber >= 1)
                return true;
            else
                return false;

        }

        public Shop_All()
        {
            InitializeComponent();
        }

        
        //Opens checkout screen and passes the current list of items as parameter
        public void openCheckOut()
        {

            bool isEmpty = !listCart.Any();
            if (isEmpty)
            {
                MessageBox.Show("Your cart is empty!");
            }
            else
            {
                co.TakeThis(listCart);
                co.StartPosition = FormStartPosition.CenterScreen;
                co.ShowDialog();
                listCart.Clear();
            }
            
        }

        private void BtnAddToCart_Click(object sender, EventArgs e)
        {
            openCheckOut();
        }

       

        private void Shop_All_Load(object sender, EventArgs e)
        {
            this.ActiveControl = lblHeader;
            

        }

       

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            int id = 100;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {

                    listCart.Add(100);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox8_Click(object sender, EventArgs e)
        {
            int id = 200;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(200);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

       

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            int id = 300;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(300);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }


        private void PictureBox1_Click(object sender, EventArgs e)
        {
            int id = 400;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(400);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox7_Click(object sender, EventArgs e)
        {
            int id = 500;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(500);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox6_Click(object sender, EventArgs e)
        {
            int id = 600;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(600);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            int id = 700;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(700);

                }
            }
            else
                MessageBox.Show("Currently Out of Stock!");
        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {
            int id = 800;
            if (checkStock(id))
            {
                var kName = helper.ExecuteScalar("Select Kayak_Name from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var color = helper.ExecuteScalar("Select Kayak_Color from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var weight = helper.ExecuteScalar("Select Kayak_Weight from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var capacity = helper.ExecuteScalar("Select Kayak_Capacity from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var length = helper.ExecuteScalar("Select Kayak_Length from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);
                var price = helper.ExecuteScalar("Select Kayak_Price from Kayaks where Kayak_ID = '" + id + "'", CommandType.Text);



                DialogResult result = MessageBox.Show("Name: " + kName.ToString() + "\nColor: " + color.ToString() + "\nWeight: " + weight.ToString() + "\nCapacity: " + capacity.ToString() + "\nLength: " + length.ToString() + "\nPrice: " + price.ToString() + "\n\nAdd to cart?", "Wet Entry Kayaks", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    listCart.Add(800);

                }
            }

            else
                MessageBox.Show("Currently Out of Stock!");
        }
    }
}
