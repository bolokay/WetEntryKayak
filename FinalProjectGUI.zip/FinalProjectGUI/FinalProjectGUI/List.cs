﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProjectGUI
{
    class List
    {
       public IList<int> ListOfInt = new List<int>();

        public void clear()
        {
            ListOfInt.Clear();
        }



    }
}
