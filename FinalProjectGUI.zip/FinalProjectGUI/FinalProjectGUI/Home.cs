﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SqlExample;

namespace FinalProjectGUI
{
    public partial class Home : Form
    {

        private SQLHelper helper = new SQLHelper();

        Shop_All sa = new Shop_All();
        New_Kayaks nk = new New_Kayaks();
        About_Us ab = new About_Us();
        Contact_Us cu = new Contact_Us();
        Check_Out co = new Check_Out();
        Login lo = new Login();
        

        public Home()
        {
            InitializeComponent();
            Color myColor = Color.FromArgb(100, Color.Black);
            lblHeader.BackColor = myColor;
            lblShopAll.BackColor = myColor;
        }

        void navigateAway()
        {
            //Hides Parent containers background
            backgroundGB.Hide();
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ab.Show();
            ab.WindowState = FormWindowState.Maximized;
            navigateAway();
        }

        private void contactUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cu.Show();
            cu.WindowState = FormWindowState.Maximized;
            navigateAway();
        }

        private void checkoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sa.openCheckOut();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lo.Show();
            lo.WindowState = FormWindowState.Maximized;
            navigateAway();
        }



        private void Home_Load(object sender, EventArgs e)
        {
            this.MainMenuStrip = new MenuStrip();



            sa.MdiParent = this;
            nk.MdiParent = this;
            ab.MdiParent = this;
            cu.MdiParent = this;
            co.MdiParent = this;
            lo.MdiParent = this;
            
        }

        private void LblShopAll_Click(object sender, EventArgs e)
        {
            sa.Show();
            sa.WindowState = FormWindowState.Maximized;
            navigateAway();
        }

        private void HomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            backgroundGB.Show();
        }

        private void ShopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sa.Show();
            sa.WindowState = FormWindowState.Maximized;
            navigateAway();
        }
    }
}
