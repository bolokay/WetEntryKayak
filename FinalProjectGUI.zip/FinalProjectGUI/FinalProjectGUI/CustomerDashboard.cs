﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SqlExample;
using System.Data.SqlClient;

namespace FinalProjectGUI
{
    public partial class CustomerDashboard : Form
    {
        SQLHelper helper = new SQLHelper();

        public CustomerDashboard()
        {
            InitializeComponent();
        }
        ///Database connection/////////////////////////////////////
        private bool makeDataBaseConnection()
        {


            helper.DBName = "PROJECTF2027";
            helper.User_Name = "PROJECTF2027";
            helper.Password = "SH93ack$";
            helper.ServerName = "essql1.walton.uark.edu";
            return true;
        }

        private void connect()
        {

            try
            {
                if (!makeDataBaseConnection())
                    MessageBox.Show("Failure to connect", "Connection Fail", MessageBoxButtons.OK);
                else if (helper.TestConnection())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        ///Database connection/////////////////////////////////////

        private void BTNOrderTracking_Click(object sender, EventArgs e)
        {
            // Launch browser to facebook...
            System.Diagnostics.Process.Start("https://www.ups.com/track?loc=en_US&requester=ST/");
        }

        public void getCustID(string custid)
        {
            //establishes connection and pulls back records for the logged in customer
            connect();
            var result = helper.GetDataTable("Select Customer_ID, First_Name, Last_Name, City, State, Country, Zip_Code, Address, Email_Address, Phone_Number FROM Customer WHERE Customer_ID = '" + custid + "'", CommandType.Text);
            DGCustomerInfo.DataSource = result;
        }

        private void CustomerDashboard_Load(object sender, EventArgs e)
        {
            DGCustomerInfo.Columns["Customer_ID"].ReadOnly = true;
        }

        private void BTNUpdateInfo_Click(object sender, EventArgs e)
        {
            try
            {
                string custid = DGCustomerInfo.CurrentRow.Cells[0].Value.ToString();
                string fname = DGCustomerInfo.CurrentRow.Cells[1].Value.ToString();
                string lname = DGCustomerInfo.CurrentRow.Cells[2].Value.ToString();
                string city = DGCustomerInfo.CurrentRow.Cells[3].Value.ToString();
                string state = DGCustomerInfo.CurrentRow.Cells[4].Value.ToString();
                string country = DGCustomerInfo.CurrentRow.Cells[5].Value.ToString();
                string zip = DGCustomerInfo.CurrentRow.Cells[6].Value.ToString();
                string address = DGCustomerInfo.CurrentRow.Cells[7].Value.ToString();
                string email = DGCustomerInfo.CurrentRow.Cells[8].Value.ToString();
                string phone = DGCustomerInfo.CurrentRow.Cells[9].Value.ToString();

                helper.ExecuteNonQuery("Update Customer SET First_Name = '" + fname + "', Last_Name = '" + lname + "', City = '" + city + "', State = '" + state + "', Country = '" + country + "', Zip_Code = '" + zip + "', Address = '" + address + "', Email_Address = '" + email + "', Phone_Number = '" + phone + "' WHERE  Customer_ID = '" + custid + "'", CommandType.Text);
                MessageBox.Show("Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BTNBack_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
